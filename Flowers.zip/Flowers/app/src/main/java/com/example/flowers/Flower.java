package com.example.flowers;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.Objects;

public class Flower extends AppCompatActivity {
    public TextView t1;
    public ImageView i1;
    public Button button2;



    @SuppressLint("SetTextI18n")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_flower);
        t1 = findViewById(R.id.textView2);
        i1 = findViewById(R.id.imageView);
        String value = getIntent().getStringExtra("flower_variant");

        button2 = findViewById(R.id.button2);
        button2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });

        if (Objects.equals(value, "img1.jpg")) {
            i1.setImageResource(R.drawable.img1);
            t1.setText("opis kwiatka nr 1");
        }
        if (Objects.equals(value, "img2.jpg")) {
            i1.setImageResource(R.drawable.img2);
            t1.setText("opis kwiatka nr 2");
        }
        if (Objects.equals(value, "img3.jpg")) {
            i1.setImageResource(R.drawable.img3);
            t1.setText("opis kwiatka nr 3");
        }
    }


}