package com.example.flowers;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.RadioButton;

public class MainActivity extends AppCompatActivity {

    private Button button;
    private Button f1;
    private Button f2;
    private Button f3;
    public String path;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        button = findViewById(R.id.button);

        f1 = findViewById(R.id.btn1);
        f2 = findViewById(R.id.btn2);
        f3 = findViewById(R.id.btn3);

        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                boolean checked_f1 = ((RadioButton) f1).isChecked();
                boolean checked_f2 = ((RadioButton) f2).isChecked();
                boolean checked_f3 = ((RadioButton) f3).isChecked();

                if(checked_f1) path = "img1.jpg";
                if(checked_f2) path = "img2.jpg";
                if(checked_f3) path = "img3.jpg";

                Intent newActivity = new Intent(MainActivity.this, Flower.class);
                newActivity.putExtra("flower_variant", path);
                startActivity(newActivity);
            }
        });
    }
}